/*
   The University of Melbourne
   School of Computing and Information Systems
   Author: Chenyuan Zhang
   Student ID: 815901
*/

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import org.json.simple.JSONObject;

public class SaveThread extends Thread{
	
	private Server server;
	
	public SaveThread(Server server) {
		this.server = server;
	}
	
	public void run() {
		
		try {
			while(true) {
				sleep(1000);
				ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(server.dictFile));
				outputStream.writeObject(ServerState.getInstance().getWordList());
				outputStream.flush();
				outputStream.close();

			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
