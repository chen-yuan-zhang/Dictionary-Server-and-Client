/*
   The University of Melbourne
   School of Computing and Information Systems
   Author: Chenyuan Zhang
   Student ID: 815901
*/

import org.json.simple.JSONObject;

public class Command {
	private boolean isFromClient;
	private boolean isExit;
	private JSONObject command;
	
	public Command(boolean isFromClient, boolean isExit, JSONObject command) {
		this.isFromClient = isFromClient;
		this.command = command;		
		this.isExit = isExit;
	}
	
	private static int minimum(int a, int b, int c) {                            
        return Math.min(Math.min(a, b), c);                                      
    }   
	
	public static int GLD(String s1, String s2) {
		int m=0,i=1,d=1,s=1,t=1;
		int l1=s1.length(),l2=s2.length();
		int[][] matrix = new int[l1+1][l2+1];
		
		for(int j=0;j<l1+1;j++) {
			matrix[j][0] = j*d;
		}
		
		for(int j=0;j<l2+1;j++) {
			matrix[0][j] = j*i;
		}
		
		for(int j=1;j<l1+1;j++) {
			for(int k=1;k<l2+1;k++) {
				int flag = (s1.charAt(j-1)==s2.charAt(k-1))? m:s;
				matrix[j][k] = minimum(matrix[j-1][k-1] + flag, matrix[j-1][k] + d, matrix[j][k-1] + i);
				if( (j>=2) && (k>=2) && (s1.charAt(j-2)==s2.charAt(k-1)) && (s1.charAt(j-1)==s2.charAt(k-2)))
					matrix[j][k] = Math.min(matrix[j][k], matrix[j-2][k-2]+t);
			}
		}
		
		return matrix[l1][l2];
	}
	
	@SuppressWarnings("finally")
	public JSONObject executeCommand() {
		String reply=null;
		JSONObject replyCommand = new JSONObject();
		int flag=0;//2 success and inform other clients, 1 success, 0 failure,
		
		try {
			switch((String) command.get("Operation")) {
				case "addWord":
					if(ServerState.getInstance().addWord((JSONObject) command.get("Item")))
					{
						reply = "Add word '" + ((JSONObject)command.get("Item")).get("Spelling") + "' successfully!";
						flag = 2;
					}
						
					else
					{
						reply = "The word '" + ((JSONObject)command.get("Item")).get("Spelling") + "' already exists!";
						flag = 0;
					}
						
					break;
				case "delWord":
					if(ServerState.getInstance().delWord(command.get("Item").toString())) {
						reply = "Delete word '" + command.get("Item") + "' successfully!";
						flag = 2;
					}
						
					else {
						String suggestion="";
						for(JSONObject candidates: ServerState.getInstance().getWordList()) {
							if (GLD(command.get("Item").toString(), candidates.get("Spelling").toString())==1) {
								suggestion = " You may want to type: " + candidates.get("Spelling");
								break;
							}
						}
						reply = "The word '" + command.get("Item") + "' is not existing!" + suggestion;
						flag = 0;
					}
						
					break;
				case "queryWord":
					JSONObject answer = ServerState.getInstance().queryWord(command.get("Item").toString());
					if (answer.containsKey("Error")){
						String suggestion="";
						for(JSONObject candidates: ServerState.getInstance().getWordList()) {
							if (GLD(command.get("Item").toString(), candidates.get("Spelling").toString())==1) {
								suggestion = " You may want to type: " + candidates.get("Spelling");
								break;
							}
						}
						reply = answer.get("Error").toString() + suggestion;
						flag = 0;
					}
					else {
						reply = answer.toString();
						flag = 1;
					}						
					break;
				default:
					break;
			}
		}catch(Exception e) {
			reply = "Not a valid command!";
		}finally {
			replyCommand.put("Info", reply);
			replyCommand.put("Type", flag);
			return replyCommand;
		}
	}
	
	public boolean isFromClient() {
		return isFromClient;
	}
	
	public boolean isExit() {
		return isExit;
	}
	
	public String getCommand() {
		return command.toString();
	}
}
