/*
   The University of Melbourne
   School of Computing and Information Systems
   Author: Chenyuan Zhang
   Student ID: 815901
*/


import java.util.ArrayList;

import org.json.simple.JSONObject;

public class ServerState {

	private static ServerState instance;
	private ArrayList<ClientConnection> connectedClients;
	private ArrayList<JSONObject> wordList;

	private ServerState() {
		connectedClients = new ArrayList<ClientConnection>();
		wordList = new ArrayList<JSONObject>();
	}

	public static synchronized ServerState getInstance() {
		if (instance == null) {
			instance = new ServerState();
		}
		return instance;
	}

	public synchronized boolean addWord(JSONObject newWord) {
		String spell = newWord.get("Spelling").toString();
		for (JSONObject word : wordList) {
			if (word.get("Spelling").toString().equals(spell))
				return false;
		}

		wordList.add(newWord);
		return true;
	}

	public synchronized boolean delWord(String spell) {
		for (JSONObject word : wordList) {
			if (word.get("Spelling").toString().equals(spell)) {
				wordList.remove(word);
				return true;
			}
		}

		return false;
	}

	@SuppressWarnings("unchecked")
	public synchronized JSONObject queryWord(String spell) {
		for (JSONObject word : wordList) {
			if (word.get("Spelling").toString().equals(spell)) {
				return word;
			}
		}

		JSONObject error = new JSONObject();
		error.put("Error", "The word '" + spell + "' is not founded!");
		return error;
	}

	public synchronized void clientConnected(ClientConnection client) {
		connectedClients.add(client);
	}

	public synchronized void clientDisconnected(ClientConnection client) {
		connectedClients.remove(client);
	}

	public synchronized ArrayList<ClientConnection> getConnectedClients() {
		return connectedClients;
	}

	public synchronized ArrayList<JSONObject> getWordList() {
		return wordList;
	}

	public synchronized void setWordList(ArrayList<JSONObject> wordList) {
		this.wordList = wordList;
	}
}
