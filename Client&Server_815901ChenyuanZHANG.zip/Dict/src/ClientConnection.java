/*
   The University of Melbourne
   School of Computing and Information Systems
   Author: Chenyuan Zhang
   Student ID: 815901
*/
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.json.simple.JSONObject;

public class ClientConnection extends Thread {

	private Socket clientSocket;
	private BufferedReader reader;
	private BufferedWriter writer;
	// This queue holds messages sent by the client or messages intended for the
	// client from other threads
	private BlockingQueue<Command> commandQueue;
	private int clientNum;

	public ClientConnection(Socket clientSocket, int clientNum) {
		try {
			this.clientSocket = clientSocket;
			this.clientNum = clientNum;
			reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream(), "UTF-8"));
			writer = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream(), "UTF-8"));
			write("Welcome! Client" + clientNum + "\r\n");
			commandQueue = new LinkedBlockingQueue<Command>();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {

		try {

			// Start the client message reader thread. It 'listens' for any
			// incoming messages from the client's socket input stream and places
			// them in a queue (producer)
			ClientCommandReader messageReader = new ClientCommandReader(reader, commandQueue);
			messageReader.setName(this.getName() + "Reader");
			messageReader.start();

			System.out.println(Thread.currentThread().getName() + " - Processing client " + clientNum + "  commands");

			// Monitor the queue to process any incoming messages (consumer)
			while (true) {

				// This method blocks until there is something to take from the queue
				// (when the messageReader receives a message and places it on the queue
				// or when another thread places a message on this client's queue)
				Command cmd = commandQueue.take();
				// process the message
				// If the message is "exit" and from a thread then
				// it means the client has closed the connection and we must
				// close the socket and update the server state
				// (See what the message reader does when it reads the end of stream
				// from the client socket)
				if (cmd.isExit()) {
					break;
				}

				if (cmd.isFromClient()) {
					JSONObject result = cmd.executeCommand();
					switch ((int) result.get("Type")) {
					case 0:
					case 1:
						write("[Private]: " + result.get("Info"));
						break;
					case 2:
						List<ClientConnection> connectedClients = ServerState.getInstance().getConnectedClients();
						for (ClientConnection client : connectedClients) {
							client.write("[Client" + clientNum + "]: " + result.get("Info"));
						}
						break;
					default:
						break;
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				clientSocket.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName() + " - Client " + clientNum + " disconnected");
			ServerState.getInstance().clientDisconnected(this);
			List<ClientConnection> connectedClients = ServerState.getInstance().getConnectedClients();
			for (ClientConnection client : connectedClients) {
				try {
					client.write("[Client" + clientNum + "]: Log off...");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public BlockingQueue<Command> getCommandQueue() {
		return commandQueue;
	}

	public int getClientNum() {
		return clientNum;
	}

	public void write(String msg) throws Exception {
		writer.write(msg + "\r\n");
		writer.flush();
		System.out.println(Thread.currentThread().getName() + " - Message sent to client " + clientNum);

	}
}
